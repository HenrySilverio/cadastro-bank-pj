import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-cadastro-page',
  templateUrl: './cadastro-page.component.html',
  styleUrls: ['./cadastro-page.component.scss']
})
export class CadastroPageComponent {
  
  constructor(private translateService: TranslateService) {
    // Inicializa o serviço de tradução com português como padrão
    this.translateService.setDefaultLang('pt-BR');
    this.translateService.use('pt-BR');
  }

  /**
   * Altera o idioma da aplicação
   * @param lang Código do idioma (pt-BR ou en)
   */
  changeLanguage(lang: string): void {
    this.translateService.use(lang);
  }
}
