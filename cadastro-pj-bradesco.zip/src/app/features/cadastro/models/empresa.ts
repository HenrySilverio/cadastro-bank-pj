export interface Empresa {
  razaoSocial: string;
  cnpj: string;
  nomeResponsavel: string;
  emailCorporativo: string;
  telefone: string;
  areaAtuacao: string;
}
